import {atom} from "recoil";

export const fullPageLoading = atom({
    default: false,
    key: 'fullPageLoading',
})
