<?php echo e($slot); ?>

<?php /**PATH F:\projects\l9R\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>