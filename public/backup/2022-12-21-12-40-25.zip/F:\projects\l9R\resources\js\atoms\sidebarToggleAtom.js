import {atom} from "recoil";

export const sidebarToggleAtom = atom({
    default: true,
    key: 'sidebarToggleAtom',
})
