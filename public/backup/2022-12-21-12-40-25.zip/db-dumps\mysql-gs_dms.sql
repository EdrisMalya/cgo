
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'Users','updated','App\\Models\\User','updated',8,'App\\Models\\User',3,'{\"attributes\":{\"name\":\"\\u0628\\u0644\\u0627\\u0644 update\",\"updated_at\":\"2022-12-18T07:21:22.197000Z\"},\"old\":{\"name\":\"\\u0628\\u0644\\u0627\\u0644\",\"updated_at\":\"2022-12-17T05:26:44.080000Z\"}}',NULL,'2022-12-18 02:51:22','2022-12-18 02:51:22'),(2,'default','I loged something',NULL,NULL,NULL,'App\\Models\\User',3,'[]',NULL,'2022-12-18 02:51:54','2022-12-18 02:51:54'),(3,'Language dictionary','created','App\\Models\\LanguageDictionary','created',101,'App\\Models\\User',1,'{\"attributes\":{\"id\":101,\"language_id\":\"1\",\"word\":\"Mr\\/Mrs [last_name] profile details\",\"translate\":\"\\u062c\\u0632\\u06cc\\u0627\\u062a \\u0645\\u062d\\u062a\\u0631\\u0645\\\\\\u0645\\u062d\\u062a\\u0631\\u0645\\u0647 [last_name]\",\"created_at\":\"2022-12-18T09:12:49.550000Z\",\"updated_at\":\"2022-12-18T09:12:49.550000Z\"}}',NULL,'2022-12-18 04:42:49','2022-12-18 04:42:49'),(4,'Users','updated','App\\Models\\User','updated',8,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Atal\",\"last_name\":\"Malia\",\"updated_at\":\"2022-12-18T10:01:13.033000Z\"},\"old\":{\"name\":\"\\u0628\\u0644\\u0627\\u0644 update\",\"last_name\":\"\\u0645\\u0644\\u06cc\\u0627\",\"updated_at\":\"2022-12-18T07:21:22.197000Z\"}}',NULL,'2022-12-18 05:31:13','2022-12-18 05:31:13'),(5,'Permission group','created','App\\Models\\PermissionGroup','created',9,'App\\Models\\User',1,'{\"attributes\":{\"id\":9,\"permission_group_id\":\"2\",\"name\":\"Log activity\",\"created_at\":\"2022-12-18T10:06:48.673000Z\",\"updated_at\":\"2022-12-18T10:06:48.673000Z\"}}',NULL,'2022-12-18 05:36:48','2022-12-18 05:36:48'),(6,'Permission','created','App\\Models\\Permission','created',26,'App\\Models\\User',1,'{\"attributes\":{\"id\":26,\"permission_group_id\":\"9\",\"name\":\"Access\",\"key\":\"log-activity-access\",\"created_at\":\"2022-12-18T10:06:53.887000Z\",\"updated_at\":\"2022-12-18T10:06:53.887000Z\"}}',NULL,'2022-12-18 05:36:53','2022-12-18 05:36:53'),(7,'Permission','created','App\\Models\\Permission','created',27,'App\\Models\\User',1,'{\"attributes\":{\"id\":27,\"permission_group_id\":\"2\",\"name\":\"View user login log\",\"key\":\"users-view-user-login-log\",\"created_at\":\"2022-12-18T10:39:43.040000Z\",\"updated_at\":\"2022-12-18T10:39:43.040000Z\"}}',NULL,'2022-12-18 06:09:43','2022-12-18 06:09:43'),(10,'Permission','created','App\\Models\\Permission','created',28,'App\\Models\\User',1,'{\"attributes\":{\"id\":28,\"permission_group_id\":\"9\",\"name\":\"View log details\",\"key\":\"log-activity-view-log-details\",\"created_at\":\"2022-12-18T11:01:30.023000Z\",\"updated_at\":\"2022-12-18T11:01:30.023000Z\"}}',NULL,'2022-12-18 06:31:30','2022-12-18 06:31:30'),(11,'Permission','created','App\\Models\\Permission','created',29,'App\\Models\\User',1,'{\"attributes\":{\"id\":29,\"permission_group_id\":\"9\",\"name\":\"Delete log\",\"key\":\"log-activity-delete-log\",\"created_at\":\"2022-12-18T11:01:48.800000Z\",\"updated_at\":\"2022-12-18T11:01:48.800000Z\"}}',NULL,'2022-12-18 06:31:48','2022-12-18 06:31:48'),(12,'Users','updated','App\\Models\\User','updated',3,'App\\Models\\User',8,'{\"attributes\":{\"name\":\"Bilal\",\"updated_at\":\"2022-12-18T11:41:26.853000Z\"},\"old\":{\"name\":\"Bilal update\",\"updated_at\":\"2022-12-18T10:53:13.923000Z\"}}',NULL,'2022-12-18 07:11:26','2022-12-18 07:11:26'),(13,'Language','created','App\\Models\\Language','created',7,'App\\Models\\User',8,'{\"attributes\":{\"id\":7,\"name\":\"Test\",\"abbr\":\"test\",\"direction\":\"ltr\",\"created_at\":\"2022-12-18T11:41:45.203000Z\",\"updated_at\":\"2022-12-18T11:41:45.203000Z\"}}',NULL,'2022-12-18 07:11:45','2022-12-18 07:11:45'),(14,'Language','deleted','App\\Models\\Language','deleted',7,'App\\Models\\User',8,'{\"old\":{\"id\":7,\"name\":\"Test\",\"abbr\":\"test\",\"direction\":\"ltr\",\"created_at\":\"2022-12-18T11:41:45.203000Z\",\"updated_at\":\"2022-12-18T11:41:45.203000Z\"}}',NULL,'2022-12-18 07:11:48','2022-12-18 07:11:48'),(15,'Users','updated','App\\Models\\User','updated',8,'App\\Models\\User',3,'{\"attributes\":{\"status\":false,\"updated_at\":\"2022-12-19T04:54:55.500000Z\"},\"old\":{\"status\":true,\"updated_at\":\"2022-12-18T10:53:03.783000Z\"}}',NULL,'2022-12-19 00:24:55','2022-12-19 00:24:55'),(16,'Language dictionary','created','App\\Models\\LanguageDictionary','created',102,'App\\Models\\User',3,'{\"attributes\":{\"id\":102,\"language_id\":\"1\",\"word\":\"User details\",\"translate\":\"\\u062c\\u0632\\u06cc\\u0627\\u062a \\u0628\\u06cc\\u0634\\u062a\\u0631 \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u0646\\u062f\\u0647\",\"created_at\":\"2022-12-19T06:01:00.613000Z\",\"updated_at\":\"2022-12-19T06:01:00.613000Z\"}}',NULL,'2022-12-19 01:31:00','2022-12-19 01:31:00'),(17,'Language dictionary','created','App\\Models\\LanguageDictionary','created',103,'App\\Models\\User',3,'{\"attributes\":{\"id\":103,\"language_id\":\"1\",\"word\":\"User profile\",\"translate\":\"\\u067e\\u0631\\u0648\\u0641\\u0627\\u06cc\\u0644 \\u06cc\\u0648\\u0632\\u0631\",\"created_at\":\"2022-12-19T06:01:32.933000Z\",\"updated_at\":\"2022-12-19T06:01:32.933000Z\"}}',NULL,'2022-12-19 01:31:33','2022-12-19 01:31:33'),(18,'Language dictionary','created','App\\Models\\LanguageDictionary','created',104,'App\\Models\\User',3,'{\"attributes\":{\"id\":104,\"language_id\":\"1\",\"word\":\"User log activity\",\"translate\":\"\\u062a\\u0645\\u0627\\u0645 \\u06a9\\u0627\\u0631\\u06a9\\u0631\\u062f \\u0647\\u0627\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u0646\\u062f\\u0647 \\u062f\\u0631 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-19T06:02:12.327000Z\",\"updated_at\":\"2022-12-19T06:02:12.327000Z\"}}',NULL,'2022-12-19 01:32:12','2022-12-19 01:32:12'),(19,'Language dictionary','created','App\\Models\\LanguageDictionary','created',105,'App\\Models\\User',3,'{\"attributes\":{\"id\":105,\"language_id\":\"1\",\"word\":\"User login activity\",\"translate\":\"\\u0644\\u06cc\\u0633\\u062a \\u0648\\u0631\\u0648\\u062f\\u06cc \\u0647\\u0627\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u0646\\u062f\\u0647 \\u062f\\u0631 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-19T06:03:16.187000Z\",\"updated_at\":\"2022-12-19T06:03:16.187000Z\"}}',NULL,'2022-12-19 01:33:16','2022-12-19 01:33:16'),(20,'Language dictionary','created','App\\Models\\LanguageDictionary','created',106,'App\\Models\\User',3,'{\"attributes\":{\"id\":106,\"language_id\":\"1\",\"word\":\"Effected module\",\"translate\":\"\\u0628\\u062e\\u0634 \\u062a\\u063a\\u06cc\\u0631 \\u06cc\\u0627\\u0641\\u062a\\u0647\",\"created_at\":\"2022-12-19T06:04:42.203000Z\",\"updated_at\":\"2022-12-19T06:04:42.203000Z\"}}',NULL,'2022-12-19 01:34:42','2022-12-19 01:34:42'),(21,'Language dictionary','created','App\\Models\\LanguageDictionary','created',107,'App\\Models\\User',3,'{\"attributes\":{\"id\":107,\"language_id\":\"1\",\"word\":\"Effected model\",\"translate\":\"\\u0645\\u0648\\u062f\\u0644 \\u062a\\u063a\\u06cc\\u0631 \\u06cc\\u0627\\u0641\\u062a\\u0647\",\"created_at\":\"2022-12-19T06:05:04.117000Z\",\"updated_at\":\"2022-12-19T06:05:04.117000Z\"}}',NULL,'2022-12-19 01:35:04','2022-12-19 01:35:04'),(22,'Language dictionary','created','App\\Models\\LanguageDictionary','created',108,'App\\Models\\User',3,'{\"attributes\":{\"id\":108,\"language_id\":\"1\",\"word\":\"Event\",\"translate\":\"\\u0631\\u0648\\u06cc\\u062f\\u0627\\u062f\",\"created_at\":\"2022-12-19T06:05:34.443000Z\",\"updated_at\":\"2022-12-19T06:05:34.443000Z\"}}',NULL,'2022-12-19 01:35:34','2022-12-19 01:35:34'),(23,'Language dictionary','created','App\\Models\\LanguageDictionary','created',109,'App\\Models\\User',3,'{\"attributes\":{\"id\":109,\"language_id\":\"1\",\"word\":\"Performed on\",\"translate\":\"\\u062a\\u0627\\u0631\\u06cc\\u062e \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0634\\u062f\\u0647\",\"created_at\":\"2022-12-19T06:06:00.687000Z\",\"updated_at\":\"2022-12-19T06:06:00.687000Z\"}}',NULL,'2022-12-19 01:36:00','2022-12-19 01:36:00'),(24,'Language dictionary','created','App\\Models\\LanguageDictionary','created',110,'App\\Models\\User',3,'{\"attributes\":{\"id\":110,\"language_id\":\"1\",\"word\":\"User activity log\",\"translate\":\"\\u062a\\u0645\\u0627\\u0645 \\u06a9\\u0627\\u0631\\u06a9\\u0631\\u062f \\u0647\\u0627\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u0646\\u062f\\u0647 \\u062f\\u0631 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-19T06:08:00.773000Z\",\"updated_at\":\"2022-12-19T06:08:00.773000Z\"}}',NULL,'2022-12-19 01:38:00','2022-12-19 01:38:00'),(25,'Language dictionary','created','App\\Models\\LanguageDictionary','created',111,'App\\Models\\User',3,'{\"attributes\":{\"id\":111,\"language_id\":\"1\",\"word\":\"deleted\",\"translate\":\"\\u062d\\u0630\\u0641 \\u0634\\u062f\\u0647\",\"created_at\":\"2022-12-19T06:10:48.610000Z\",\"updated_at\":\"2022-12-19T06:10:48.610000Z\"}}',NULL,'2022-12-19 01:40:48','2022-12-19 01:40:48'),(26,'Language dictionary','created','App\\Models\\LanguageDictionary','created',112,'App\\Models\\User',3,'{\"attributes\":{\"id\":112,\"language_id\":\"1\",\"word\":\"updated\",\"translate\":\"\\u062a\\u062c\\u062f\\u06cc\\u062f \\u06af\\u0631\\u06cc\\u062f\\u0647\",\"created_at\":\"2022-12-19T06:11:16.683000Z\",\"updated_at\":\"2022-12-19T06:11:16.683000Z\"}}',NULL,'2022-12-19 01:41:16','2022-12-19 01:41:16'),(27,'Language dictionary','created','App\\Models\\LanguageDictionary','created',113,'App\\Models\\User',3,'{\"attributes\":{\"id\":113,\"language_id\":\"1\",\"word\":\"created\",\"translate\":\"\\u0627\\u06cc\\u062c\\u0627\\u062f \\u0634\\u062f\\u0647\",\"created_at\":\"2022-12-19T06:12:12.447000Z\",\"updated_at\":\"2022-12-19T06:12:12.447000Z\"}}',NULL,'2022-12-19 01:42:12','2022-12-19 01:42:12'),(28,'Language dictionary','created','App\\Models\\LanguageDictionary','created',114,'App\\Models\\User',3,'{\"attributes\":{\"id\":114,\"language_id\":\"1\",\"word\":\"Log details\",\"translate\":\"\\u062c\\u0632\\u06cc\\u0627\\u062a\",\"created_at\":\"2022-12-19T06:12:59.777000Z\",\"updated_at\":\"2022-12-19T06:12:59.777000Z\"}}',NULL,'2022-12-19 01:42:59','2022-12-19 01:42:59'),(29,'Language dictionary','created','App\\Models\\LanguageDictionary','created',115,'App\\Models\\User',3,'{\"attributes\":{\"id\":115,\"language_id\":\"1\",\"word\":\"Activity details\",\"translate\":\"\\u062c\\u0632\\u06cc\\u0627\\u062a \\u0641\\u0639\\u0627\\u0644\\u06cc\\u062a\",\"created_at\":\"2022-12-19T06:13:35.817000Z\",\"updated_at\":\"2022-12-19T06:13:35.817000Z\"}}',NULL,'2022-12-19 01:43:35','2022-12-19 01:43:35'),(30,'Language dictionary','created','App\\Models\\LanguageDictionary','created',116,'App\\Models\\User',3,'{\"attributes\":{\"id\":116,\"language_id\":\"1\",\"word\":\"Action type\",\"translate\":\"\\u0646\\u0648\\u0639 \\u0639\\u0645\\u0644\",\"created_at\":\"2022-12-19T06:13:56.200000Z\",\"updated_at\":\"2022-12-19T06:13:56.200000Z\"}}',NULL,'2022-12-19 01:43:56','2022-12-19 01:43:56'),(31,'Language dictionary','created','App\\Models\\LanguageDictionary','created',117,'App\\Models\\User',3,'{\"attributes\":{\"id\":117,\"language_id\":\"1\",\"word\":\"Effected on\",\"translate\":\"\\u0628\\u062e\\u0634 \\u062a\\u063a\\u06cc\\u0631 \\u06cc\\u0627\\u0641\\u062a\\u0647\",\"created_at\":\"2022-12-19T06:14:23.297000Z\",\"updated_at\":\"2022-12-19T06:14:23.297000Z\"}}',NULL,'2022-12-19 01:44:23','2022-12-19 01:44:23'),(32,'Language dictionary','created','App\\Models\\LanguageDictionary','created',118,'App\\Models\\User',3,'{\"attributes\":{\"id\":118,\"language_id\":\"1\",\"word\":\"Date\",\"translate\":\"\\u062a\\u0627\\u0631\\u06cc\\u062e\",\"created_at\":\"2022-12-19T06:14:34.560000Z\",\"updated_at\":\"2022-12-19T06:14:34.560000Z\"}}',NULL,'2022-12-19 01:44:34','2022-12-19 01:44:34'),(33,'Language dictionary','created','App\\Models\\LanguageDictionary','created',119,'App\\Models\\User',3,'{\"attributes\":{\"id\":119,\"language_id\":\"1\",\"word\":\"Field name\",\"translate\":\"\\u0627\\u0633\\u0645 \\u0628\\u062e\\u0634\",\"created_at\":\"2022-12-19T06:17:00.060000Z\",\"updated_at\":\"2022-12-19T06:17:00.060000Z\"}}',NULL,'2022-12-19 01:47:00','2022-12-19 01:47:00'),(34,'Language dictionary','created','App\\Models\\LanguageDictionary','created',120,'App\\Models\\User',3,'{\"attributes\":{\"id\":120,\"language_id\":\"1\",\"word\":\"Field value\",\"translate\":\"\\u062f\\u06cc\\u062a\\u0627\\u06cc \\u0628\\u062e\\u0634\",\"created_at\":\"2022-12-19T06:17:39.753000Z\",\"updated_at\":\"2022-12-19T06:17:39.753000Z\"}}',NULL,'2022-12-19 01:47:39','2022-12-19 01:47:39'),(35,'Language dictionary','created','App\\Models\\LanguageDictionary','created',121,'App\\Models\\User',3,'{\"attributes\":{\"id\":121,\"language_id\":\"1\",\"word\":\"updated at\",\"translate\":\"\\u062a\\u062c\\u062f\\u06cc\\u062f \\u06af\\u0631\\u062f\\u06cc\\u062f\\u0647 \\u062f\\u0631\",\"created_at\":\"2022-12-19T06:19:19.920000Z\",\"updated_at\":\"2022-12-19T06:19:19.920000Z\"}}',NULL,'2022-12-19 01:49:19','2022-12-19 01:49:19'),(36,'Language dictionary','created','App\\Models\\LanguageDictionary','created',122,'App\\Models\\User',3,'{\"attributes\":{\"id\":122,\"language_id\":\"1\",\"word\":\"abbr\",\"translate\":\"\\u062a\\u062e\\u0641\\u0641\",\"created_at\":\"2022-12-19T06:19:37.297000Z\",\"updated_at\":\"2022-12-19T06:19:37.297000Z\"}}',NULL,'2022-12-19 01:49:37','2022-12-19 01:49:37'),(37,'Language dictionary','created','App\\Models\\LanguageDictionary','created',123,'App\\Models\\User',3,'{\"attributes\":{\"id\":123,\"language_id\":\"1\",\"word\":\"IP address\",\"translate\":\"\\u0622\\u062f\\u0631\\u0633 \\u0622\\u06cc \\u067e\\u06cc\",\"created_at\":\"2022-12-19T06:21:02.997000Z\",\"updated_at\":\"2022-12-19T06:21:02.997000Z\"}}',NULL,'2022-12-19 01:51:03','2022-12-19 01:51:03'),(38,'Language dictionary','created','App\\Models\\LanguageDictionary','created',124,'App\\Models\\User',3,'{\"attributes\":{\"id\":124,\"language_id\":\"1\",\"word\":\"WAS LOGIN SUCCEED\",\"translate\":\"\\u0648\\u0631\\u0648\\u062f \\u0628\\u0627 \\u0645\\u0648\\u0641\\u0642\\u06cc\\u062a \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0634\\u062f\",\"created_at\":\"2022-12-19T06:21:22.583000Z\",\"updated_at\":\"2022-12-19T06:21:22.583000Z\"}}',NULL,'2022-12-19 01:51:22','2022-12-19 01:51:22'),(39,'Language dictionary','created','App\\Models\\LanguageDictionary','created',125,'App\\Models\\User',3,'{\"attributes\":{\"id\":125,\"language_id\":\"1\",\"word\":\"Logged in date\",\"translate\":\"\\u062a\\u0627\\u0631\\u06cc\\u062e \\u0648\\u0631\\u0648\\u062f \\u0628\\u0647 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-19T06:22:14.450000Z\",\"updated_at\":\"2022-12-19T06:22:14.450000Z\"}}',NULL,'2022-12-19 01:52:14','2022-12-19 01:52:14'),(40,'Permission group','created','App\\Models\\PermissionGroup','created',10,'App\\Models\\User',1,'{\"attributes\":{\"id\":10,\"permission_group_id\":\"1\",\"name\":\"Login log\",\"created_at\":\"2022-12-19T06:28:45.597000Z\",\"updated_at\":\"2022-12-19T06:28:45.597000Z\"}}',NULL,'2022-12-19 01:58:45','2022-12-19 01:58:45'),(41,'Permission','created','App\\Models\\Permission','created',30,'App\\Models\\User',1,'{\"attributes\":{\"id\":30,\"permission_group_id\":\"10\",\"name\":\"Access\",\"key\":\"login-log-access\",\"created_at\":\"2022-12-19T06:29:09.220000Z\",\"updated_at\":\"2022-12-19T06:29:09.220000Z\"}}',NULL,'2022-12-19 01:59:09','2022-12-19 01:59:09'),(42,'Permission','created','App\\Models\\Permission','created',31,'App\\Models\\User',1,'{\"attributes\":{\"id\":31,\"permission_group_id\":\"10\",\"name\":\"Truncate\",\"key\":\"login-log-truncate\",\"created_at\":\"2022-12-19T06:29:17.940000Z\",\"updated_at\":\"2022-12-19T06:29:17.940000Z\"}}',NULL,'2022-12-19 01:59:18','2022-12-19 01:59:18'),(43,'default','truncated',NULL,NULL,NULL,'App\\Models\\User',3,'[]',NULL,'2022-12-19 03:33:20','2022-12-19 03:33:20'),(44,'default','truncated',NULL,NULL,NULL,'App\\Models\\User',3,'[]',NULL,'2022-12-19 03:53:44','2022-12-19 03:53:44'),(45,'Login log','truncated',NULL,NULL,NULL,'App\\Models\\User',3,'[]',NULL,'2022-12-19 04:00:16','2022-12-19 04:00:16'),(46,'Permission group','created','App\\Models\\PermissionGroup','created',11,'App\\Models\\User',1,'{\"attributes\":{\"id\":11,\"permission_group_id\":4,\"name\":\"Backups\",\"created_at\":\"2022-12-19T11:07:06.000000Z\",\"updated_at\":\"2022-12-19T11:07:06.000000Z\"}}',NULL,'2022-12-19 11:07:06','2022-12-19 11:07:06'),(47,'Permission','created','App\\Models\\Permission','created',32,'App\\Models\\User',1,'{\"attributes\":{\"id\":32,\"permission_group_id\":11,\"name\":\"Access\",\"key\":\"backups-access\",\"created_at\":\"2022-12-19T11:07:12.000000Z\",\"updated_at\":\"2022-12-19T11:07:12.000000Z\"}}',NULL,'2022-12-19 11:07:12','2022-12-19 11:07:12'),(48,'Language dictionary','created','App\\Models\\LanguageDictionary','created',126,'App\\Models\\User',3,'{\"attributes\":{\"id\":126,\"language_id\":1,\"word\":\"Backups\",\"translate\":\"\\u067e\\u0634\\u062a\\u06cc\\u0628\\u0627\\u0646 \\u06af\\u06cc\\u0631\\u06cc\",\"created_at\":\"2022-12-20T05:52:35.000000Z\",\"updated_at\":\"2022-12-20T05:52:35.000000Z\"}}',NULL,'2022-12-20 05:52:35','2022-12-20 05:52:35'),(49,'Language dictionary','created','App\\Models\\LanguageDictionary','created',127,'App\\Models\\User',3,'{\"attributes\":{\"id\":127,\"language_id\":1,\"word\":\"All available backups\",\"translate\":\"\\u062a\\u0645\\u0627\\u0645 \\u0646\\u0633\\u062e\\u0647 \\u0647\\u0627\\u06cc \\u067e\\u0634\\u062a\\u06cc\\u0628\\u0627\\u0646 \\u0645\\u0648\\u062c\\u0648\\u062f\",\"created_at\":\"2022-12-20T05:52:57.000000Z\",\"updated_at\":\"2022-12-20T05:52:57.000000Z\"}}',NULL,'2022-12-20 05:52:57','2022-12-20 05:52:57'),(50,'Language dictionary','created','App\\Models\\LanguageDictionary','created',128,'App\\Models\\User',3,'{\"attributes\":{\"id\":128,\"language_id\":1,\"word\":\"Login log\",\"translate\":\"\\u0631\\u0627\\u067e\\u0648\\u0631 \\u0648\\u0631\\u0648\\u062f \\u0628\\u0647 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-20T05:53:46.000000Z\",\"updated_at\":\"2022-12-20T05:53:46.000000Z\"}}',NULL,'2022-12-20 05:53:46','2022-12-20 05:53:46'),(51,'Language dictionary','created','App\\Models\\LanguageDictionary','created',129,'App\\Models\\User',3,'{\"attributes\":{\"id\":129,\"language_id\":1,\"word\":\"User login log\",\"translate\":\"\\u0631\\u0627\\u067e\\u0648\\u0631 \\u0648\\u0631\\u0648\\u062f\\u06cc \\u0647\\u0627 \\u06a9\\u0627\\u0631\\u0628\\u0631\\u0627\\u0646 \\u062f\\u0631 \\u0633\\u06cc\\u0633\\u062a\\u0645\",\"created_at\":\"2022-12-20T05:54:27.000000Z\",\"updated_at\":\"2022-12-20T05:54:27.000000Z\"}}',NULL,'2022-12-20 05:54:27','2022-12-20 05:54:27'),(52,'Language dictionary','created','App\\Models\\LanguageDictionary','created',130,'App\\Models\\User',3,'{\"attributes\":{\"id\":130,\"language_id\":1,\"word\":\"Truncate\",\"translate\":\"\\u062d\\u0630\\u0641 \\u0647\\u0645\\u0647\",\"created_at\":\"2022-12-20T05:54:45.000000Z\",\"updated_at\":\"2022-12-20T05:54:45.000000Z\"}}',NULL,'2022-12-20 05:54:45','2022-12-20 05:54:45'),(53,'Login log','truncated',NULL,NULL,NULL,'App\\Models\\User',3,'[]',NULL,'2022-12-20 06:17:09','2022-12-20 06:17:09'),(54,'Role','created','App\\Models\\Role','created',2,'App\\Models\\User',3,'{\"attributes\":{\"id\":2,\"created_by\":3,\"updated_by\":0,\"role_group_id\":1,\"name\":\"User manager\",\"created_at\":\"2022-12-20T06:23:18.000000Z\",\"updated_at\":\"2022-12-20T06:23:18.000000Z\"}}',NULL,'2022-12-20 06:23:18','2022-12-20 06:23:18'),(55,'Role','updated','App\\Models\\Role','updated',2,'App\\Models\\User',3,'{\"attributes\":{\"updated_by\":3,\"updated_at\":\"2022-12-20T06:23:26.000000Z\"},\"old\":{\"updated_by\":0,\"updated_at\":\"2022-12-20T06:23:18.000000Z\"}}',NULL,'2022-12-20 06:23:26','2022-12-20 06:23:26'),(56,'Role','deleted','App\\Models\\Role','deleted',2,'App\\Models\\User',3,'{\"old\":{\"id\":2,\"created_by\":3,\"updated_by\":3,\"role_group_id\":1,\"name\":\"User manager\",\"created_at\":\"2022-12-20T06:23:18.000000Z\",\"updated_at\":\"2022-12-20T06:23:26.000000Z\"}}',NULL,'2022-12-20 06:24:23','2022-12-20 06:24:23'),(57,'Permission group','created','App\\Models\\PermissionGroup','created',12,'App\\Models\\User',1,'{\"attributes\":{\"id\":12,\"permission_group_id\":0,\"name\":\"Test\",\"created_at\":\"2022-12-21T08:01:59.000000Z\",\"updated_at\":\"2022-12-21T08:01:59.000000Z\"}}',NULL,'2022-12-21 08:01:59','2022-12-21 08:01:59'),(58,'Permission group','deleted','App\\Models\\PermissionGroup','deleted',12,'App\\Models\\User',1,'{\"old\":{\"id\":12,\"permission_group_id\":0,\"name\":\"Test\",\"created_at\":\"2022-12-21T08:01:59.000000Z\",\"updated_at\":\"2022-12-21T08:01:59.000000Z\"}}',NULL,'2022-12-21 08:02:06','2022-12-21 08:02:06'),(59,'Users','deleted','App\\Models\\User','deleted',8,'App\\Models\\User',1,'{\"old\":{\"id\":8,\"name\":\"Atal\",\"last_name\":\"Malia\",\"email\":\"bilalmalya@gmail.com\",\"phone_number\":\"+937813537171\",\"email_verified_at\":null,\"password\":\"$2y$10$QdtMpqCK5KNRXC6FOWC0iObCYR.nrtnXEqcQ\\/UkJ40WJTHD0DZy7u\",\"status\":false,\"change_password\":false,\"image\":\"users_picture\\/NWBrLS4ZSNvSLh5iXHKeZcmueINQCZEKyGBjFCKC.jpg\",\"remember_token\":null,\"created_at\":\"2022-12-17T00:56:44.000000Z\",\"updated_at\":\"2022-12-19T00:24:55.000000Z\"}}',NULL,'2022-12-21 08:02:15','2022-12-21 08:02:15'),(60,'Role','created','App\\Models\\Role','created',3,'App\\Models\\User',3,'{\"attributes\":{\"id\":3,\"created_by\":3,\"updated_by\":0,\"role_group_id\":1,\"name\":\"Test\",\"created_at\":\"2022-12-21T08:04:42.000000Z\",\"updated_at\":\"2022-12-21T08:04:42.000000Z\"}}',NULL,'2022-12-21 08:04:42','2022-12-21 08:04:42'),(61,'Role','deleted','App\\Models\\Role','deleted',3,'App\\Models\\User',3,'{\"old\":{\"id\":3,\"created_by\":3,\"updated_by\":0,\"role_group_id\":1,\"name\":\"Test\",\"created_at\":\"2022-12-21T08:04:42.000000Z\",\"updated_at\":\"2022-12-21T08:04:42.000000Z\"}}',NULL,'2022-12-21 08:05:00','2022-12-21 08:05:00'),(62,'Users','created','App\\Models\\User','created',9,'App\\Models\\User',3,'{\"attributes\":{\"id\":9,\"name\":\"Gillian\",\"last_name\":\"Clayton\",\"email\":\"haqy@mailinator.com\",\"phone_number\":\"+1 (567) 109-1454\",\"email_verified_at\":null,\"password\":\"$2y$10$G3ZZY7V2d8SyCkzHVTfZ8.sOHGqpIsVilTJ30vHgjtinpCerzPkSG\",\"status\":true,\"change_password\":true,\"image\":\"users_picture\\/FckETvUWX13RwA2wEaNE9wt9m5vypmalCBcpV2Hs.jpg\",\"remember_token\":null,\"created_at\":\"2022-12-21T08:07:02.000000Z\",\"updated_at\":\"2022-12-21T08:07:02.000000Z\"}}',NULL,'2022-12-21 08:07:02','2022-12-21 08:07:02');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `language_dictionaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_dictionaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` bigint(20) unsigned NOT NULL,
  `word` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `translate` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `language_dictionaries` WRITE;
/*!40000 ALTER TABLE `language_dictionaries` DISABLE KEYS */;
INSERT INTO `language_dictionaries` VALUES (6,1,'Add new word','افزودن لغت جدید','2022-12-14 02:34:07','2022-12-14 02:34:07'),(11,1,'[language] language dictionary','ذخیره لغات زبان [language]','2022-12-14 05:37:41','2022-12-15 01:07:31'),(12,1,'Add language','اضافه نمودن زبان','2022-12-14 07:05:05','2022-12-14 07:05:05'),(13,1,'Dari','دری','2022-12-15 01:06:50','2022-12-15 01:06:50'),(15,6,'[language] language dictionary','ده [language] ژبه لغاتونه','2022-12-15 02:21:56','2022-12-15 02:31:31'),(16,6,'Add new word','نوی لغت اضافه کول','2022-12-15 02:25:34','2022-12-15 02:25:34'),(17,6,'Pashto','پشتو','2022-12-15 02:26:08','2022-12-15 02:26:08'),(18,1,'Pashto','پشتو','2022-12-15 04:11:47','2022-12-15 04:11:47'),(19,1,'Dashboard','داشبورد','2022-12-15 04:37:02','2022-12-15 04:37:02'),(20,1,'User management','مدریت استفاده کننده ها','2022-12-15 04:37:24','2022-12-17 06:45:05'),(21,1,'Configuration','تنظیمات','2022-12-15 04:38:22','2022-12-15 04:38:22'),(22,1,'Word','لغت','2022-12-15 04:46:19','2022-12-15 04:46:19'),(23,1,'Translate','ترجمه','2022-12-15 04:46:36','2022-12-15 04:46:36'),(24,1,'Created at','ایجاد شده در','2022-12-15 04:47:01','2022-12-15 04:47:01'),(25,1,'Actions','اجرآت','2022-12-15 04:47:49','2022-12-15 04:47:49'),(26,1,'ID','آی دی','2022-12-15 04:48:05','2022-12-15 04:48:05'),(27,1,'NO#','شماره','2022-12-15 04:48:24','2022-12-15 04:49:10'),(28,1,'Collapse \nsidebar','بسته نمودن ساید بار','2022-12-17 00:25:19','2022-12-17 00:25:33'),(29,1,'Language','زبان','2022-12-17 00:25:59','2022-12-17 00:25:59'),(30,1,'My profile','پروفایل من','2022-12-17 00:26:45','2022-12-17 00:26:45'),(31,1,'Logout','خروج از سیستم','2022-12-17 00:27:00','2022-12-17 00:27:00'),(32,1,'Users','استفاده کننده ها','2022-12-17 00:27:54','2022-12-17 00:27:54'),(33,1,'Roles','صلاحیت ها','2022-12-17 00:29:17','2022-12-17 00:29:17'),(34,1,'List users','لیست استفاده کننده ها','2022-12-17 00:33:27','2022-12-17 00:33:27'),(35,1,'Add new user','ایجاد یوزر جدید','2022-12-17 00:34:11','2022-12-17 00:34:11'),(36,1,'Name','اسم','2022-12-17 00:34:46','2022-12-17 00:34:46'),(37,1,'Email','ایمیل','2022-12-17 00:34:57','2022-12-17 00:34:57'),(38,1,'Status','حالت','2022-12-17 00:35:10','2022-12-17 00:35:10'),(39,1,'Phone number','شماره تماس','2022-12-17 00:35:26','2022-12-17 00:35:26'),(40,1,'Search','جستجو','2022-12-17 00:39:18','2022-12-17 00:39:18'),(41,1,'Number of record','تعداد نمایش عداد در صفحه','2022-12-17 00:41:09','2022-12-17 00:41:09'),(42,1,'No record found','هیج نو معلومات دریافت نشد','2022-12-17 00:42:12','2022-12-17 00:42:12'),(43,1,'Hello - [first_name] [last_name]','سلام [first_name] [last_name]','2022-12-17 00:43:50','2022-12-17 00:43:50'),(44,1,'User Form','فورم استفاده کننده ها','2022-12-17 00:48:40','2022-12-17 00:48:40'),(45,1,'Profile picture','عکس استفاده کننده','2022-12-17 00:49:13','2022-12-17 00:49:13'),(46,1,'First name','اسم','2022-12-17 00:49:36','2022-12-17 00:49:36'),(47,1,'Last name','تخلص','2022-12-17 00:49:52','2022-12-17 00:49:52'),(48,1,'Password','رمز','2022-12-17 00:50:34','2022-12-17 00:50:34'),(49,1,'Confirm password','تاییدی رمز','2022-12-17 00:50:50','2022-12-17 00:50:50'),(50,1,'Show password','نمایش رمز','2022-12-17 00:51:06','2022-12-17 00:51:06'),(51,1,'Save','ثبت','2022-12-17 00:51:32','2022-12-17 00:51:32'),(52,1,'Close','بستن','2022-12-17 00:51:44','2022-12-17 00:51:44'),(53,1,'Active','فعلل','2022-12-17 00:57:00','2022-12-17 00:57:00'),(54,1,'Inactive','غیر فعال','2022-12-17 00:57:14','2022-12-17 00:57:14'),(55,1,'Super admin','ادیمن عمومی','2022-12-17 03:55:52','2022-12-17 03:55:52'),(56,1,'Updated successfully','موفقانه تجدید گردید','2022-12-17 05:39:47','2022-12-17 05:56:33'),(57,1,'Are you sure you want to delete','آیا شما مطمین هستید','2022-12-17 06:04:27','2022-12-17 06:04:27'),(58,1,'List of roles','لیست صلاحیت ها','2022-12-17 06:06:00','2022-12-17 06:06:53'),(59,1,'Create role group','ایجاد گروپ جدید برای صلاحیت ها','2022-12-17 06:07:45','2022-12-17 06:07:45'),(60,1,'Admins','مدیران','2022-12-17 06:08:30','2022-12-17 06:08:30'),(61,1,'Role group','گروپ صلاحیت ها','2022-12-17 06:14:37','2022-12-17 06:14:37'),(62,1,'Role','صلاحیت','2022-12-17 06:15:10','2022-12-17 06:15:10'),(63,1,'Role group name','اسم گروپ صلاحت ها','2022-12-17 06:15:43','2022-12-17 06:15:43'),(64,1,'Role name','اسم صلاحیت','2022-12-17 06:15:59','2022-12-17 06:15:59'),(65,1,'The name field is required.','بخش اسم ضرور میباشد','2022-12-17 06:23:50','2022-12-17 06:23:50'),(66,1,'Role details','جزیات صلاحیت','2022-12-17 06:27:38','2022-12-17 06:27:38'),(67,1,'Created by','ایجاد شده توسط','2022-12-17 06:28:26','2022-12-17 06:28:26'),(68,1,'Updated by','تجدید شده توسط','2022-12-17 06:28:43','2022-12-17 06:28:43'),(69,1,'Role all assigned permissions','تمام دسترسی های موجود','2022-12-17 06:30:22','2022-12-17 06:30:22'),(70,1,'Permissions','دسترسی ها','2022-12-17 06:32:59','2022-12-17 06:32:59'),(71,1,'Groups','گروپ ها','2022-12-17 06:33:26','2022-12-17 06:33:26'),(72,1,'Access','اجازه','2022-12-17 06:35:07','2022-12-17 06:35:07'),(73,1,'Create user','ایجاد یوزر','2022-12-17 06:36:11','2022-12-17 06:36:11'),(74,1,'Edit user','تجدید یوزر','2022-12-17 06:36:25','2022-12-17 06:36:25'),(75,1,'Delete user','حذف یوزر','2022-12-17 06:36:45','2022-12-17 06:36:45'),(76,1,'View profile','مشاهده جزیات یوزر','2022-12-17 06:37:17','2022-12-17 06:37:32'),(77,1,'View role details','مشاهده جزیات صلاحیت','2022-12-17 06:38:14','2022-12-17 06:38:14'),(78,1,'Create role','ایجاد صلاحیت','2022-12-17 06:38:28','2022-12-17 06:38:28'),(79,1,'Edit role','تجدید صلاحیت','2022-12-17 06:38:46','2022-12-17 06:38:46'),(80,1,'Delete role','حذف صلاحیت','2022-12-17 06:39:01','2022-12-17 06:39:01'),(81,1,'Create language','ایجاد زبان','2022-12-17 06:39:42','2022-12-17 06:39:42'),(82,1,'Edit language name','تجدید اسم زبان','2022-12-17 06:40:07','2022-12-17 06:40:07'),(83,1,'Delete language','حذف زبان','2022-12-17 06:40:22','2022-12-17 06:40:22'),(84,1,'Language dictionary','ذخیره لغات زبان','2022-12-17 06:40:57','2022-12-17 06:40:57'),(85,1,'Add new word to dictionary','اضافه کردن لغت جدید در ذخیره لغات','2022-12-17 06:41:57','2022-12-17 06:41:57'),(86,1,'Edit word','تجدید لغت','2022-12-17 06:42:13','2022-12-17 06:42:13'),(87,1,'Delete word','حذف لغت','2022-12-17 06:42:28','2022-12-17 06:42:28'),(88,1,'This is user management section','بخش مدریت استفاده کننده ها','2022-12-17 06:44:28','2022-12-17 06:44:28'),(89,1,'Welcome to configuration page','خوش آمدید به صفحه تنظیمات','2022-12-17 06:46:04','2022-12-17 06:46:04'),(90,1,'Languages','زبان ها','2022-12-17 06:49:04','2022-12-17 06:49:04'),(91,1,'Are you sure you want to delete this group','آیا شما مطمین هستید که میخواهد ای گروپ ره حذف نمایید','2022-12-17 06:50:04','2022-12-17 06:51:42'),(92,1,'Are you sure you want to delete this role?','آیا شما مطمین هستید که میخواهید ای صلاحیت ره حذف نمایید','2022-12-17 06:52:32','2022-12-17 06:52:32'),(93,1,'Language list','لیست زبان ها','2022-12-17 06:53:14','2022-12-17 06:53:14'),(94,1,'Language form','فورم زبان','2022-12-17 06:56:08','2022-12-17 06:56:08'),(95,1,'Language name','اسم زبان','2022-12-17 06:56:49','2022-12-17 06:56:49'),(96,1,'Language abbreviation','مخفف زبان','2022-12-17 06:57:05','2022-12-17 06:57:05'),(97,1,'Direction','مسیر صفحه','2022-12-17 06:57:26','2022-12-17 06:57:26'),(98,1,'Right to left','راست به چپ','2022-12-17 06:57:41','2022-12-17 06:57:41'),(99,1,'Left to right','چپ به راست','2022-12-17 06:57:55','2022-12-17 06:57:55'),(100,1,'Welcome to the Dashboard','خوش آمدید به صفحه اصلی','2022-12-17 07:00:31','2022-12-17 07:00:31'),(101,1,'Mr/Mrs [last_name] profile details','جزیات محترم\\محترمه [last_name]','2022-12-18 04:42:49','2022-12-18 04:42:49'),(102,1,'User details','جزیات بیشتر استفاده کننده','2022-12-19 01:31:00','2022-12-19 01:31:00'),(103,1,'User profile','پروفایل یوزر','2022-12-19 01:31:32','2022-12-19 01:31:32'),(104,1,'User log activity','تمام کارکرد های استفاده کننده در سیستم','2022-12-19 01:32:12','2022-12-19 01:32:12'),(105,1,'User login activity','لیست ورودی های استفاده کننده در سیستم','2022-12-19 01:33:16','2022-12-19 01:33:16'),(106,1,'Effected module','بخش تغیر یافته','2022-12-19 01:34:42','2022-12-19 01:34:42'),(107,1,'Effected model','مودل تغیر یافته','2022-12-19 01:35:04','2022-12-19 01:35:04'),(108,1,'Event','رویداد','2022-12-19 01:35:34','2022-12-19 01:35:34'),(109,1,'Performed on','تاریخ انجام شده','2022-12-19 01:36:00','2022-12-19 01:36:00'),(110,1,'User activity log','تمام کارکرد های استفاده کننده در سیستم','2022-12-19 01:38:00','2022-12-19 01:38:00'),(111,1,'deleted','حذف شده','2022-12-19 01:40:48','2022-12-19 01:40:48'),(112,1,'updated','تجدید گریده','2022-12-19 01:41:16','2022-12-19 01:41:16'),(113,1,'created','ایجاد شده','2022-12-19 01:42:12','2022-12-19 01:42:12'),(114,1,'Log details','جزیات','2022-12-19 01:42:59','2022-12-19 01:42:59'),(115,1,'Activity details','جزیات فعالیت','2022-12-19 01:43:35','2022-12-19 01:43:35'),(116,1,'Action type','نوع عمل','2022-12-19 01:43:56','2022-12-19 01:43:56'),(117,1,'Effected on','بخش تغیر یافته','2022-12-19 01:44:23','2022-12-19 01:44:23'),(118,1,'Date','تاریخ','2022-12-19 01:44:34','2022-12-19 01:44:34'),(119,1,'Field name','اسم بخش','2022-12-19 01:47:00','2022-12-19 01:47:00'),(120,1,'Field value','دیتای بخش','2022-12-19 01:47:39','2022-12-19 01:47:39'),(121,1,'updated at','تجدید گردیده در','2022-12-19 01:49:19','2022-12-19 01:49:19'),(122,1,'abbr','تخفف','2022-12-19 01:49:37','2022-12-19 01:49:37'),(123,1,'IP address','آدرس آی پی','2022-12-19 01:51:02','2022-12-19 01:51:02'),(124,1,'WAS LOGIN SUCCEED','ورود با موفقیت انجام شد','2022-12-19 01:51:22','2022-12-19 01:51:22'),(125,1,'Logged in date','تاریخ ورود به سیستم','2022-12-19 01:52:14','2022-12-19 01:52:14'),(126,1,'Backups','پشتیبان گیری','2022-12-20 05:52:35','2022-12-20 05:52:35'),(127,1,'All available backups','تمام نسخه های پشتیبان موجود','2022-12-20 05:52:57','2022-12-20 05:52:57'),(128,1,'Login log','راپور ورود به سیستم','2022-12-20 05:53:46','2022-12-20 05:53:46'),(129,1,'User login log','راپور ورودی ها کاربران در سیستم','2022-12-20 05:54:27','2022-12-20 05:54:27'),(130,1,'Truncate','حذف همه','2022-12-20 05:54:45','2022-12-20 05:54:45');
/*!40000 ALTER TABLE `language_dictionaries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'Dari','da','rtl','2022-12-14 02:31:43','2022-12-14 02:33:41'),(6,'Pashto','pas','rtl','2022-12-15 02:20:12','2022-12-15 02:20:48');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_logs_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
INSERT INTO `login_logs` VALUES (1,'edris.malya@dab.gov.af','127.0.0.1','login',1,'2022-12-20 11:02:24','2022-12-20 11:02:24'),(2,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-20 11:15:40','2022-12-20 11:15:40'),(3,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-20 11:15:41','2022-12-20 11:15:41'),(4,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-20 11:15:42','2022-12-20 11:15:42'),(5,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-20 11:15:43','2022-12-20 11:15:43'),(6,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-20 11:15:45','2022-12-20 11:15:45'),(7,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-21 04:29:05','2022-12-21 04:29:05'),(8,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-21 04:29:06','2022-12-21 04:29:06'),(9,'adrismalya@gmail.com','127.0.0.1','login',1,'2022-12-21 04:29:11','2022-12-21 04:29:11'),(10,'edris.malya@dab.gov.af','127.0.0.1','login',1,'2022-12-21 08:00:24','2022-12-21 08:00:24'),(11,'edris.malya@dab.gov.af','127.0.0.1','login',1,'2022-12-21 08:00:52','2022-12-21 08:00:52'),(12,'adrismalya@gmail.com','127.0.0.1','login',0,'2022-12-21 08:01:01','2022-12-21 08:01:01'),(13,'adrismalya@gmail.com','127.0.0.1','login',1,'2022-12-21 08:01:05','2022-12-21 08:01:05');
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_11_30_050041_create_permission_groups_table',1),(6,'2022_12_02_181022_create_permissions_table',1),(7,'2022_12_06_052144_create_roles_table',1),(8,'2022_12_06_052517_create_role_groups_table',1),(9,'2022_12_06_105233_create_role_permissions_table',1),(10,'2022_12_10_051106_create_user_roles_table',2),(11,'2022_12_12_070531_create_languages_table',3),(12,'2022_12_13_071728_create_language_dictionaries_table',4),(13,'2022_12_18_070817_create_activity_log_table',5),(14,'2022_12_18_070818_add_event_column_to_activity_log_table',5),(15,'2022_12_18_070819_add_batch_uuid_column_to_activity_log_table',5),(16,'2022_12_18_073237_create_login_logs_table',6),(17,'2022_12_19_102550_create_system_backup_logs_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permission_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permission_groups` WRITE;
/*!40000 ALTER TABLE `permission_groups` DISABLE KEYS */;
INSERT INTO `permission_groups` VALUES (1,0,'User management','2022-12-11 01:34:50','2022-12-11 01:34:50'),(2,1,'Users','2022-12-11 01:35:03','2022-12-11 01:35:03'),(3,1,'Roles','2022-12-11 01:35:11','2022-12-11 01:35:11'),(4,0,'Configuration','2022-12-11 05:54:12','2022-12-11 05:54:12'),(5,4,'Language','2022-12-11 06:13:17','2022-12-11 06:13:17'),(6,5,'Language dictionary','2022-12-13 00:57:22','2022-12-13 00:57:22'),(9,2,'Log activity','2022-12-18 05:36:48','2022-12-18 05:36:48'),(10,1,'Login log','2022-12-19 01:58:45','2022-12-19 01:58:45'),(11,4,'Backups','2022-12-19 11:07:06','2022-12-19 11:07:06');
/*!40000 ALTER TABLE `permission_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_group_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,1,'Access','user-management-access','2022-12-11 01:34:55','2022-12-11 01:34:55'),(2,2,'Access','users-access','2022-12-11 01:35:18','2022-12-11 01:35:18'),(3,2,'Create user','users-create-user','2022-12-11 01:35:30','2022-12-11 01:35:30'),(4,2,'Edit user','users-edit-user','2022-12-11 01:35:39','2022-12-11 01:35:39'),(5,2,'Delete user','users-delete-user','2022-12-11 01:35:48','2022-12-11 01:35:48'),(6,3,'Access','roles-access','2022-12-11 01:35:55','2022-12-11 01:35:55'),(9,3,'View role details','roles-view-role-details','2022-12-11 01:36:23','2022-12-11 01:36:23'),(10,3,'Create role','roles-create-role','2022-12-11 01:36:50','2022-12-11 01:36:50'),(11,3,'Edit role','roles-edit-role','2022-12-11 01:36:54','2022-12-11 01:36:54'),(12,3,'Delete role','roles-delete-role','2022-12-11 01:36:58','2022-12-11 01:36:58'),(13,2,'View profile','users-view-profile','2022-12-11 03:43:11','2022-12-11 03:43:11'),(14,4,'Access','configuration-access','2022-12-11 05:54:17','2022-12-11 05:54:17'),(15,5,'Access','language-access','2022-12-11 06:13:21','2022-12-11 06:13:21'),(16,5,'Create language','language-create-language','2022-12-12 01:52:13','2022-12-12 01:52:13'),(17,5,'Edit language name','language-edit-language-name','2022-12-13 00:56:42','2022-12-13 00:56:42'),(18,5,'Delete language','language-delete-language','2022-12-13 00:56:49','2022-12-13 00:56:49'),(19,6,'Access','language-dictionary-access','2022-12-13 00:57:28','2022-12-13 00:57:28'),(21,6,'Add new word to dictionary','language-dictionary-add-new-word-to-dictionary','2022-12-13 01:14:26','2022-12-13 01:14:26'),(22,6,'Edit word','language-dictionary-edit-word','2022-12-13 03:02:33','2022-12-13 03:02:33'),(23,6,'Delete word','language-dictionary-delete-word','2022-12-13 03:02:39','2022-12-13 03:02:39'),(26,9,'Access','log-activity-access','2022-12-18 05:36:53','2022-12-18 05:36:53'),(27,2,'View user login log','users-view-user-login-log','2022-12-18 06:09:43','2022-12-18 06:09:43'),(28,9,'View log details','log-activity-view-log-details','2022-12-18 06:31:30','2022-12-18 06:31:30'),(29,9,'Delete log','log-activity-delete-log','2022-12-18 06:31:48','2022-12-18 06:31:48'),(30,10,'Access','login-log-access','2022-12-19 01:59:09','2022-12-19 01:59:09'),(31,10,'Truncate','login-log-truncate','2022-12-19 01:59:17','2022-12-19 01:59:17'),(32,11,'Access','backups-access','2022-12-19 11:07:12','2022-12-19 11:07:12');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_groups_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_groups` WRITE;
/*!40000 ALTER TABLE `role_groups` DISABLE KEYS */;
INSERT INTO `role_groups` VALUES (1,'Admins','2022-12-11 01:37:05','2022-12-11 01:37:05');
/*!40000 ALTER TABLE `role_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=877 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (851,1,4,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(852,1,5,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(853,1,3,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(854,1,2,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(855,1,6,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(856,1,9,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(857,1,11,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(858,1,10,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(859,1,12,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(860,1,15,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(861,1,16,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(862,1,17,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(863,1,18,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(864,1,19,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(865,1,21,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(866,1,22,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(867,1,23,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(868,1,14,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(869,1,26,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(870,1,27,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(871,1,28,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(872,1,29,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(873,1,30,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(874,1,32,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(875,1,1,'2022-12-21 08:07:49','2022-12-21 08:07:49'),(876,1,13,'2022-12-21 08:07:49','2022-12-21 08:07:49');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` bigint(20) unsigned NOT NULL DEFAULT 0,
  `updated_by` bigint(20) unsigned NOT NULL DEFAULT 0,
  `role_group_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,1,1,1,'Super admin','2022-12-11 01:37:09','2022-12-17 03:56:59');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,2,1,'2022-12-11 01:38:37','2022-12-11 01:38:37'),(18,3,1,'2022-12-18 07:11:26','2022-12-18 07:11:26'),(20,9,1,'2022-12-21 08:07:02','2022-12-21 08:07:02');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `change_password` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ahmad Edris','Malia','edris.malya@dab.gov.af','+93781357171',NULL,'$2y$10$02./WWYTrZqRK8dTrlEts.gaPFdq5UcNMJ8.qtWB4pNBHu4lzas6u',1,0,'users_picture/RMcNrJNazPLc6Cs2FUeTDwdBivTVYI3XnEaS5VI0.jpg',NULL,'2022-12-13 06:07:32','2022-12-13 06:17:15'),(3,'Bilal','Malia','adrismalya@gmail.com','0799210807',NULL,'$2y$10$BwjMNrHTiXQEYBViUUluVeGCoG4KyugyRxkDl4Wepi.K70C3JywOG',1,0,'users_picture/KMLcxCM8DqWwlyWeB41nUOwADC5qPA2YDLQWrvQh.jpg',NULL,'2022-12-11 02:35:06','2022-12-18 07:11:26'),(9,'Gillian','Clayton','haqy@mailinator.com','+1 (567) 109-1454',NULL,'$2y$10$G3ZZY7V2d8SyCkzHVTfZ8.sOHGqpIsVilTJ30vHgjtinpCerzPkSG',1,1,'users_picture/FckETvUWX13RwA2wEaNE9wt9m5vypmalCBcpV2Hs.jpg',NULL,'2022-12-21 08:07:02','2022-12-21 08:07:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

